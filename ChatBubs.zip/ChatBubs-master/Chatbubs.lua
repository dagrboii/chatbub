
local frame = CreateFrame("Frame", "pfChatBubbles", UIParent)
frame:RegisterEvent("CHAT_MSG_SAY")
frame:RegisterEvent("CHAT_MSG_YELL")
frame:RegisterEvent("CHAT_MSG_PARTY")
frame:RegisterEvent("CHAT_MSG_PARTY_LEADER")
frame:RegisterEvent("CHAT_MSG_MONSTER_SAY")
frame:RegisterEvent("CHAT_MSG_MONSTER_YELL")
frame:RegisterEvent("CHAT_MSG_MONSTER_PARTY")

frame:SetScript("OnEvent", function()
    frame:SetScript("OnUpdate", frame.ScanBubbles)
end)

function frame:IsBubble(f)
    if f:GetName() then return end
    if not f:GetRegions() then return end
    return f:GetRegions().GetTexture and f:GetRegions():GetTexture() == "Interface\\Tooltips\\ChatBubble-Background"
end

function frame:ProcessBubble(f)
    f.text:Hide()
    f.text:SetFont("Fonts\\FRIZQT__.TTF", tonumber(13) * UIParent:GetScale(), "OUTLINE")
    local r,g,b,a = f.text:GetTextColor()
    f.frame.text:SetText(f.text:GetText())
    f.frame.text:SetTextColor(r,g,b,a)
end

function frame:ScanBubbles()
    local childs = { WorldFrame:GetChildren() }
    for _, f in pairs(childs) do
        if not f.frame and frame:IsBubble(f) then
        local textures = {f:GetRegions()}
        for _, object in pairs(textures) do
            if object:GetObjectType() == "Texture" then
            object:SetTexture('')
            elseif object:GetObjectType() == 'FontString' then
            f.text = object
            end
        end

        f.frame = CreateFrame("Frame", nil, f)
        f.frame:SetScale(UIParent:GetScale())
        f.frame:SetAllPoints(f)

        f.frame.text = f.frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        f.frame.text:SetFont("Fonts\\FRIZQT__.TTF", 17, "OUTLINE")
        f.frame.text:SetTextColor(1,1,1,1)
        f.frame.text:SetJustifyH("CENTER")
        f.frame.text:SetJustifyV("CENTER")
        f.frame.text:SetAllPoints(f.frame)

        frame:ProcessBubble(f)

        f:SetScript("OnShow", function()
            frame:ProcessBubble(this)
        end)
        end
    end

    frame:SetScript("OnUpdate", nil)
end